<? 
/*Include Files*/
session_start(); 
include("database.php");
include("login.php");

?>

<html>
<title>Login</title>
<body>

<? displayLogin(); ?>

</body>
</html>
