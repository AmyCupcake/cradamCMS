<?php echo getcwd(); ?>
